export const projects = [
  {
    id: '1',
    title: '1385 OTTAWA AVENUE',
    location: 'WEST VANCOUVER',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80'
  },
  {
    id: '2',
    title: '1406 PEMBERTON AVENUE',
    location: 'NORTH VANCOUVER',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-1.2.1&auto=format&fit=crop&w=2070&q=80'
  },
  {
    id: '3',
    title: '1225 RENTON ROAD',
    location: 'WEST VANCOUVER',
    image: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80'
  },
  {
    id: '4',
    title: '372 ST. JAMES CRESCENT',
    location: 'WEST VANCOUVER',
    image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80'
  },
  {
    id: '5',
    title: '4262 LIONS AVENUE',
    location: 'NORTH VANCOUVER',
    image: 'https://images.unsplash.com/photo-1600607687644-c7171b42498b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80'
  },
  {
    id: '6',
    title: '2592 ROSEBERY AVENUE',
    location: 'WEST VANCOUVER',
    image: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80'
  }
];