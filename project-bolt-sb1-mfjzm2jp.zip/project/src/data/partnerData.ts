export const partners = [
  {
    id: 'bar-burrito',
    name: 'Bar Burrito',
    logo: 'https://i.ibb.co/yNNT3pj/Bar-Burrito.jpg',
    website: '#'
  },
  {
    id: 'big-fresh-kitchen',
    name: 'Big Fresh Kitchen',
    logo: 'https://i.ibb.co/QHCrkP8/BIg-Fresh-Kitchen.jpg',
    website: '#'
  },
  {
    id: 'dominos',
    name: 'Dominos',
    logo: 'https://i.ibb.co/5K0PvRV/Dominos-Logo.jpg',
    website: '#'
  },
  {
    id: 'evas-original',
    name: "Eva's Original",
    logo: 'https://i.ibb.co/BgHYDzn/Evas-Orginal.jpg',
    website: '#'
  },
  {
    id: 'marble-slab',
    name: 'Marble Slab',
    logo: 'https://i.ibb.co/BV2n4VD/Marble-Slab-Logo.jpg',
    website: '#'
  }
];