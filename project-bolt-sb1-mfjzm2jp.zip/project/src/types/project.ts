export interface Project {
  id: string;
  title: string;
  location: string;
  image: string;
}